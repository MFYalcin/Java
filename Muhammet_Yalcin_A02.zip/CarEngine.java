public class CarEngine {

    private static final int CC_FROM_HP = (int) 0.0667;
    private static final int RADIANS_PER_SECOND = (int) 5252.0;
    private float engineDisplacement;
    private float horsePower;
    private int numCylinders;
    private int stroke;
    private int boreSize;
    private int speed;
    private int torque;
    private String companyName;

    public CarEngine() {
        engineDisplacement = 0f;
        horsePower = 0f;
        numCylinders = 0;
        stroke = 0;
        boreSize = 0;
        speed = 0;
        torque = 0;
        companyName = "Unknown";
    }

    public CarEngine(String companyName, int torque, int speed, int boreSize, int stroke, int numCylinders) {
        // Use the parameters to set the class attributes
        if (companyName == null) {
            this.companyName = "Unknown";
        }
        this.companyName = companyName;
        this.torque = torque;
        this.speed = speed;
        this.boreSize = boreSize;
        this.stroke = stroke;
        this.numCylinders = numCylinders;
        if (torque < 0) {
            this.torque = 0;
        }
        if (speed < 0) {
            this.speed = 0;
        }
        if (boreSize < 0) {
            this.boreSize = 0;
        }
        if (stroke < 0) {
            this.stroke = 0;
        }
        if (boreSize > 100) {
            this.boreSize = 100;
        }
        if (stroke > 100) {
            this.stroke = 100;
        }
        if (numCylinders < 0) {
            this.numCylinders = 0;
        }
        if (numCylinders > 8) {
            this.numCylinders = 8;
        }


    }

    private float calculateHorsePowerFromTorque() {
        return torque * (speed / RADIANS_PER_SECOND);
    }

    int radius;

    private float calculateEngineDisplacement() {
        return (float) (Math.PI * radius * 2 * stroke * numCylinders);
    }

    private float calculateHorsepowerFromDisplacement() {
        return engineDisplacement / 15;
    }

    public void setCompanyName(String companyName) {
        if (companyName == null) {
            this.companyName = "Unknown";
        } else {
            this.companyName = companyName;
        }
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setEngineDisplacement() {
        this.engineDisplacement = calculateEngineDisplacement();
    }

    public float getEngineDisplacement() {
        return engineDisplacement;
    }

    public void setHorsePower(boolean source) {
        if (source) {
            this.horsePower = calculateHorsepowerFromDisplacement();
        }
        else{
            this.horsePower = calculateHorsePowerFromTorque();
        }
    }

    public float getHorsePower() {
        return horsePower;
    }

    public void setTorque(int torque) {
        this.torque = torque;
    }

    public int getTorque() {
        return torque;
    }

    public void setBoreSize(int boreSize) {
        this.boreSize = boreSize;
    }

    public int getBoreSize() {
        return boreSize;
    }

    public void setStroke(int stroke) {
        this.stroke = stroke;
    }

    public int getStroke() {
        return stroke;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getSpeed() {
        return speed;
    }

    public void setNumCylinders(int numCylinders) {
        this.numCylinders = numCylinders;
    }

    public int getNumCylinders() {
        return numCylinders;
    }

}
