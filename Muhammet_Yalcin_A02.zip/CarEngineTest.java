import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;

class CarEngineTest {

    private static CarEngine engine;

    @BeforeAll
    static void setUp() {
        engine = new CarEngine(); // Default constructor
    }

    @AfterAll
    static void tearDown() {
        engine = null; // Clean up after each test
    }

    @Test
    void testOverloadedConstructor() {
        CarEngine overloadedEngine = new CarEngine("Stark",300, 4, 61, 4000, 8);
        assertEquals(300, overloadedEngine.getTorque());
        assertEquals(4, overloadedEngine.getBoreSize());
        assertEquals(61, overloadedEngine.getStroke());
        assertEquals(4000, overloadedEngine.getSpeed());
        assertEquals(8, overloadedEngine.getNumCylinders());
    }

    @Test
    void testSetCompanyName() {
        engine.setCompanyName("Ford");
        assertEquals("Ford", engine.getCompanyName());
    }

    @Test
    void testSetNumCylinders() {
        engine.setNumCylinders(4);
        assertEquals(4, engine.getNumCylinders());
    }

    @Test
    void testSetBoreSize() {
        engine.setBoreSize(4);
        assertEquals(4.0, engine.getBoreSize());
    }

    @Test
    void testSetEngineDisplacement() {
        engine.setEngineDisplacement();
        assertEquals(5.5f, engine.getEngineDisplacement());
    }

    @Test
    void testSetHorsePower() {
        engine.setHorsePower(true); // Or false depending on your specific logic
        assertNotNull(engine.getHorsePower());
    }
}


