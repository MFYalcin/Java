import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
        ArrayList<CarEngine> engines = new ArrayList<>();

        // Add 5 CarEngine objects to the ArrayList
        engines.add(new CarEngine("Ford", 6, 3, 1500, 2,20));
        engines.add(new CarEngine("Chevrolet", 4, 2, 1800, 40,100));
        engines.add(new CarEngine("Honda", 4, 17, 2000, 75,29));
        engines.add(new CarEngine("Toyota", 8, 4, 2500, 40,18));
        engines.add(new CarEngine("Tesla", 0, 100, 0, 0,0)); // Electric
        CarEngine engine1 = new CarEngine("Stark", 4, 5, 1500, 200, 20);
        printEngineDetails(engine1);
    }

    static void printEngineDetails(CarEngine engine1) {
        System.out.println("Company Name: " + engine1.getCompanyName());
        System.out.println("Number of Cylinders: " + engine1.getNumCylinders());
        System.out.println("Bore Size: " + engine1.getBoreSize());
        System.out.println("Engine Displacement: " + engine1.getEngineDisplacement());
        System.out.println("Horse Power: " + engine1.getHorsePower());
    }

}
