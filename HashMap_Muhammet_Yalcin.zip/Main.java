import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        HashMap<String, Profile> users = new HashMap<>();
        Scanner scanner = new Scanner(System.in);
        final int MAX_ATTEMPTS = 3;

        while (true) {
            System.out.println("Press any key to register or press 'Q' to quit");
            String input = scanner.nextLine().toUpperCase();

            if (input.equals("Q")) {
                break;
            }

            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine();
            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine();
            System.out.print("Enter password: ");
            String profilePassword = scanner.nextLine();
            System.out.print("Enter Date of Birth: ");
            String date = scanner.nextLine();
            Profile profile2 = new Profile();
            profile2.setFirstName(firstName);
            profile2.setLastName(lastName);
            profile2.setProfilePassword(profilePassword);
            profile2.setDateOfBirth(date);
            profile2.setLastLogged();
            profile2.setUserName();
            profile2.printProfile();
            users.put(firstName + lastName, profile2);

        }

        scanner.close();


        for (HashMap.Entry<String, Profile> user : users.entrySet()) {
            Profile userProfile = user.getValue();
            System.out.println("Username: " + user.getKey());
            System.out.println("First Name: " + userProfile.getFirstName());
            System.out.println("Last Name: " + userProfile.getLastName());
            System.out.println("Password: " + userProfile.getProfilePassword());
            System.out.println("D.O.B: " + userProfile.getDateOfBirth());
            System.out.println("Last Logged: " + userProfile.getLastLogged());
            System.out.println("------------------------");
        }

        Profile Pw = new Profile();
        if (!users.containsKey(Pw.userName())) {
            System.out.println("Username doesn't exist!");
            return;
        }

        int attempts = 0;

        while (attempts < MAX_ATTEMPTS) {

            if (users.containsKey(Pw.getProfilePassword())) {
                System.out.println("User logged in!");
                Pw.printProfile();
                return;
            } else {
                System.out.println("Incorrect password. Please try again.");
                attempts++;

            }

            System.out.println("Max number of wrong attempts reached!");
        }

        }
}








