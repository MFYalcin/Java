import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.security.MessageDigest;
public class Profile {

    private LocalDateTime lastLogged;
    private boolean loggedIn;

    private String profilePassword = "Default password";
    private String userName;


    private LocalDate dateOfBirth;

    private String lastName = "Default last";
    private String firstName = "Default first";

    public void printProfile() {
        System.out.println("------------------------");
        System.out.println("Username: " + userName);
        System.out.println("Name: " + userName);
        System.out.println("Password : " + profilePassword);
        System.out.println("D.O.B.: " + dateOfBirth);
        System.out.println("Last logged in: " + lastLogged);
        System.out.println("------------------------");
    }

    public boolean checkPassword(String enteredPassword) {
        if (this.profilePassword.equals(hashText(enteredPassword))) {
            this.loggedIn = true;
            this.setLastLogged();
            return true;
        } else {
            this.loggedIn = false;
            return false;
        }
    }

    public LocalDateTime getLastLogged() {
        return lastLogged;
    }

    public String getProfilePassword() {
        return profilePassword;
    }

    public String userName() {
        return userName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public String getLastName() {

        return lastName;
    }

    public String getFirstName() {

        return firstName;
    }

    private void setLoggedIn(boolean loggedIn) {
        this.loggedIn = loggedIn;

    }

    public void setDateOfBirth(String date) {
        this.dateOfBirth = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }

    public void setLastLogged() {
        this.lastLogged = LocalDateTime.now();
    }

    public void setProfilePassword(String profilePassword) {
        this.profilePassword = hashText(profilePassword);
    }

    public void setUserName() {
        this.userName = userName;

    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Profile() {

        firstName = "Harry";
        lastName = "Potter";
        userName = firstName + "" + lastName;
        profilePassword = hashText(profilePassword);
        dateOfBirth = LocalDate.of(2023, 1, 1);
        lastLogged = LocalDateTime.now();




    }

    public void setLastLogged(LocalDateTime lastLogged) {
        this.lastLogged = lastLogged;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public String getUserName() {
        return firstName +  lastName;
    }


    private String hashText(String profilePassword) {

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] messageDigest = md.digest(profilePassword.getBytes());
            BigInteger messageNumber = new BigInteger(1, messageDigest);
            String hashText = messageNumber.toString(16);

            while (hashText.length() < 64) {
                hashText = "0" + hashText;
            }
            return hashText;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

}

