import java.util.LinkedList;

/**
 * This class represents a shipping container with contents tracked using RFID technology.
 */
public class ShippingContainerRFID extends ShipContainer {
    private LinkedList<String> contents;
    private LinkedList<Integer> count;

    /**
     * Constructs a ShippingContainerRFID object with the given container ID.
     * Initializes the lists to track contents and their quantities.
     * @param containerID The ID of the shipping container.
     */
    public ShippingContainerRFID(int containerID) {
        super(containerID);
        this.contents = new LinkedList<>();
        this.count = new LinkedList<>();
    }

    /**
     * Adds an item to the container's list of contents.
     * @param item The item to be added.
     */
    public void setContents(String item) {
        int index = contents.indexOf(item);
        if (index != -1) {
            count.set(index, count.get(index) + 1);
        } else {
            contents.add(item);
            count.add(1);
        }
    }

    /**
     * Overrides the containerContentList() method to return a formatted string of contents and their quantities.
     * @return The formatted contents of the container.
     */
    @Override
    public String containerContentList() {
        StringBuilder contentList = new StringBuilder();
        for (int i = 0; i < contents.size(); i++) {
            contentList.append(count.get(i)).append(" ").append(contents.get(i));
            if (i < contents.size() - 1) {
                contentList.append(" ");
            }
        }
        return contentList.toString();
    }
}
