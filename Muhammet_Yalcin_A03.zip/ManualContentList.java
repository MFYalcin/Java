/**
 * This class represents a list of contents manually inventoried for a shipping container.
 */
public class ManualContentList extends ShipContainer {
    private String contents;

    /**
     * Constructs a ManualContentList object with the given container ID.
     * @param containerID The ID of the shipping container.
     */
    public ManualContentList(int containerID) {
        super(containerID);
        this.contents = "";
    }

    /**
     * Sets the contents of the shipping container.
     * @param contents The contents to be set.
     */
    public void setContents(String contents) {
        this.contents = contents;
    }

    /**
     * Overrides the containerContentList() method to return the manually inventoried contents.
     * @return The contents of the container.
     */
    @Override
    public String containerContentList() {
        return contents;
    }
}