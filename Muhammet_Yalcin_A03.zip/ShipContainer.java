/**
 * This class represents a shipping container with a unique ID.
 */
public class ShipContainer {
    protected int containerID;

    /**
     * Constructs a ShipContainer object with the given container ID.
     * @param containerID The ID of the shipping container.
     */
    public ShipContainer(int containerID) {
        this.containerID = containerID;
    }

    /**
     * Returns an empty string representing the container's content list.
     * @return An empty string.
     */
    public String containerContentList() {
        return "";
    }

    /**
     * Prints the contents of the shipping container.
     */
    public void printContent() {
        System.out.println("Container ID: " + containerID);
        System.out.println("Contents: " + containerContentList());
    }
}
