import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<ShipContainer> containers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("M - Add Manual Content List");
            System.out.println("R - Add Shipping Container with RFID");
            System.out.println("P - Print Container Details");
            System.out.println("Q - Quit");

            String option = scanner.nextLine().toUpperCase();

            switch (option) {
                case "M":
                    System.out.println("Enter container ID:");
                    int containerID = Integer.parseInt(scanner.nextLine());
                    ManualContentList manualContainer = new ManualContentList(containerID);
                    System.out.println("Enter container contents:");
                    String contents = scanner.nextLine();
                    manualContainer.setContents(contents);
                    containers.add(manualContainer);
                    break;

                case "R":
                    System.out.println("Enter container ID:");
                    int rfidContainerID = Integer.parseInt(scanner.nextLine());
                    ShippingContainerRFID rfidContainer = new ShippingContainerRFID(rfidContainerID);
                    System.out.println("Enter item to be added:");
                    String item = scanner.nextLine();
                    rfidContainer.setContents(item);
                    containers.add(rfidContainer);
                    break;

                case "P":
                    for (ShipContainer container : containers) {
                        container.printContent();
                    }
                    break;

                case "Q":
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid option. Please choose a valid option.");
            }
        }
    }
}
