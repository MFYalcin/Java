/**
 * A Heater models a simple space-heater. The operations provided by a Heater
 * object are:
 * 1. Increase and decrease the temperature setting by a set amount.
 * 2. Return the current temperature setting.
 * 3. Change the set amount by which the temperature is increased and lowered.
 * 
 * @author L.S. Marshall, SCE, Carleton University
 * (incomplete implementation for SYSC 2004 Lab 2)
 * @author Muhammet Furkan Yalcin
 * 1.03 July 11th, 2023
 */
public class Heater
{
    /** The temperature setting that the heater should maintain. */
    private int temperature;
    private int min;
    private int max;
    
    /** The temperature setting for a newly created heater. */
    private static final int INITIAL_TEMPERATURE = 15;


    
    /** 
     * The amount by which the temperature setting is raised/lowered when
     * warmer() and cooler() are invoked.
     */
     private int increment;

    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    public int getIncrement() {
        return increment;
    }

    Heater heater;
    int minTemperature = heater.getMin();
    int maxTemperature = heater.getMax();
    int temperatureIncrement = heater.getIncrement();
    /** 
     * The default amount by which the temperature setting is 
     * increased when warmer() is invoked and decreased when cooler()
     * is invoked.
     */
    private static final int DEFAULT_INCREMENT = 5;
    
    /**
     * Constructs a new Heater with an initial temperature setting of 15
     * degrees, and which increments and decrements the temperature
     * setting in increments of 5 degrees.
     */
    public Heater()
    {
        temperature = INITIAL_TEMPERATURE;
        increment = DEFAULT_INCREMENT;
        min = 0;
        max = 100;
    }
 
    /**
     * public Heater() has 2 parameters which take min and max temperature values.,
     */    
    public Heater(int minTemp, int maxTemp)
    {
        min = minTemp;
        max = maxTemp;
        temperature = INITIAL_TEMPERATURE;
        increment = DEFAULT_INCREMENT;
    }

    /**
     * We have public int temperature() inside of public class Heater which is reachable in every document.
     *      * temperature() always return 0, but we get the current temperature settings by just putting the temperature of private int temperature;
     */    
    public int temperature()
    {
        return temperature;
    }
    
    /**
     * We put warmer() as temperature raises and that is initializing the temperature and then add the increment
     */
    public void warmer()
    {
        temperature = temperature + increment;

    }

    /**
     * Same thing with the cooler but subtracting the increment.
     */    
    public void cooler()
    {
        temperature = temperature - increment;
    }
    
    
    /**
     * We basically set newIncrement to increment file since it is private, and it will be the actual new increment.
     */    
    public void setIncrement(int newIncrement)
    {
        if (newIncrement > 0){
            increment = newIncrement;

        }
    }
}
