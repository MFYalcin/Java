import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class HeaterTest {


    private static Heater heater;
    private static int counter;

    @BeforeAll
    private static void setUp() {
        heater = null;
        counter = 0;

    }

    @AfterEach
    private void summary(){
        counter += 1;
        System.out.println("Number of tests executed: " + counter);
    }

    @AfterAll
    private static void tearDown() {
        System.out.println("All tests are done");
    }
    public int temperature;

    @Test
    private void test_DefaultConstructor() {
        heater = new Heater(); // Create an object using the default constructor
        int expectedTemperature = 15;
        int actualTemperature = heater.temperature(); // Get the actual temperature using the temperature() method
        assertEquals(expectedTemperature, actualTemperature); // Compare the expected and actual temperature values
    }

    @Test
    public void test_OverloadedConstructor() {
        int expectedMin = 0;
        int expectedMax = 100;
        heater = new Heater(expectedMin, expectedMax); // Create an object using the overloaded constructor
        int actualMin = heater.getMin(); // Get the actual min value using the getMin() method
        int actualMax = heater.getMax(); // Get the actual max value using the getMax() method

        assertEquals(expectedMin, actualMin); // Compare the expected and actual min values
        assertEquals(expectedMax, actualMax); // Compare the expected and actual max values

        int expectedTemperature = (expectedMin + expectedMax) / 2;
        int actualTemperature = heater.temperature(); // Get the actual temperature using the temperature() method
        int expectedIncrement = 5;
        int actualIncrement = heater.getIncrement(); // Get the actual increment using the getIncrement() method

        assertEquals(expectedTemperature, actualTemperature); // Compare the expected and actual temperature values
        assertEquals(expectedIncrement, actualIncrement); // Compare the expected and actual increment values
    }

    @Test
    private void test_OverloadedConstructor_MinIsLargerThanMax() {
        int expectedMin = 100;
        int expectedMax = 0;

        heater = new Heater(expectedMin, expectedMax); // Create an object using the overloaded constructor
        int actualMin = heater.getMin(); // Get the actual min value using the getMin() method
        int actualMax = heater.getMax(); // Get the actual max value using the getMax() method

        assertEquals(expectedMax, actualMin); // Compare the expected and actual min values (since min > max)
        assertEquals(expectedMin, actualMax); // Compare the expected and actual max values (since min > max)

        int expectedTemperature = (expectedMin + expectedMax) / 2;
        int actualTemperature = heater.temperature(); // Get the actual temperature using the temperature() method
        int expectedIncrement = 5;
        int actualIncrement = heater.getIncrement(); // Get the actual increment using the getIncrement() method

        assertEquals(expectedTemperature, actualTemperature); // Compare the expected and actual temperature values
        assertEquals(expectedIncrement, actualIncrement); // Compare the expected and actual increment values
    }
    @Test
    private void test_setIncrement_CallWarmerThenCooler() {
        heater = new Heater(); // Create an object using the default constructor

        int initialTemperature = heater.temperature(); // Get the initial temperature

        int newIncrement = 4;
        heater.setIncrement(newIncrement); // Set the new increment value

        heater.warmer(); // Increase the temperature using the new increment
        int expectedTemperatureAfterWarmer = initialTemperature + newIncrement;
        int actualTemperatureAfterWarmer = heater.temperature(); // Get the actual temperature after calling warmer

        assertEquals(expectedTemperatureAfterWarmer, actualTemperatureAfterWarmer); // Compare the expected and actual temperature values after calling warmer

        heater.cooler(); // Decrease the temperature using the new increment
        int expectedTemperatureAfterCooler = expectedTemperatureAfterWarmer - newIncrement;
        int actualTemperatureAfterCooler = heater.temperature(); // Get the actual temperature after calling cooler

        assertEquals(expectedTemperatureAfterCooler, actualTemperatureAfterCooler); // Compare the expected and actual temperature values after calling cooler
    }
    @Test
    private void test_setIncrement_ZeroAndNegativeIncrement() {
        heater = new Heater(); // Create an object using the default constructor

        int initialTemperature = heater.temperature(); // Get the initial temperature

        // Test case: Set increment to zero
        int zeroIncrement = 0;
        heater.setIncrement(zeroIncrement); // Set the increment to zero

        heater.warmer(); // Try increasing the temperature with zero increment
        int expectedTemperatureZeroIncrement = initialTemperature;
        int actualTemperatureZeroIncrement = heater.temperature(); // Get the actual temperature after calling warmer

        assertEquals(expectedTemperatureZeroIncrement, actualTemperatureZeroIncrement); // Compare the expected and actual temperature values after calling warmer

        heater.cooler(); // Try decreasing the temperature with zero increment
        int expectedTemperatureZeroIncrementCooler = expectedTemperatureZeroIncrement;
        int actualTemperatureZeroIncrementCooler = heater.temperature(); // Get the actual temperature after calling cooler

        assertEquals(expectedTemperatureZeroIncrementCooler, actualTemperatureZeroIncrementCooler); // Compare the expected and actual temperature values after calling cooler

        // Test case: Set increment to negative value
        int negativeIncrement = -3;
        heater.setIncrement(negativeIncrement); // Set the increment to a negative value

        heater.warmer(); // Try increasing the temperature with a negative increment
        int expectedTemperatureNegativeIncrement = expectedTemperatureZeroIncrement;
        int actualTemperatureNegativeIncrement = heater.temperature(); // Get the actual temperature after calling warmer

        assertEquals(expectedTemperatureNegativeIncrement, actualTemperatureNegativeIncrement); // Compare the expected and actual temperature values after calling warmer

        heater.cooler(); // Try decreasing the temperature with a negative increment
        int expectedTemperatureNegativeIncrementCooler = expectedTemperatureNegativeIncrement + negativeIncrement;
        int actualTemperatureNegativeIncrementCooler = heater.temperature(); // Get the actual temperature after calling cooler

        assertEquals(expectedTemperatureNegativeIncrementCooler, actualTemperatureNegativeIncrementCooler); // Compare the expected and actual temperature values after calling cooler
    }

    @Test
    private void test_Max_WarmerAndCoolerToLimits() {
        int min = 0;
        int max = 100;
        heater = new Heater(min, max); // Create an object using the overloaded constructor with specific min and max values

        int initialTemperature = heater.temperature(); // Get the initial temperature

        // Test case: Try increasing the temperature to the maximum limit
        while (heater.temperature() < max) {
            heater.warmer();
        }

        int expectedTemperatureMaxLimit = max;
        int actualTemperatureMaxLimit = heater.temperature(); // Get the actual temperature after calling warmer repeatedly

        assertEquals(expectedTemperatureMaxLimit, actualTemperatureMaxLimit); // Compare the expected and actual temperature values after reaching the max limit

        // Test case: Try decreasing the temperature to the minimum limit
        while (heater.temperature() > min) {
            heater.cooler();
        }

        int expectedTemperatureMinLimit = min;
        int actualTemperatureMinLimit = heater.temperature(); // Get the actual temperature after calling cooler repeatedly

        assertEquals(expectedTemperatureMinLimit, actualTemperatureMinLimit); // Compare the expected and actual temperature values after reaching the min limit
    }

}






