public class Main {
    public static void main(String[] args) {
        // Part 1
        RollOverCounter counter = new RollOverCounter(1,5);
        // Predict the initial value
        // Prediction: The initial value will be 1
        System.out.println(counter.getMinimumCount()); // Should print 1

        // Invoke increment
        // Prediction: The value will increase by 1 to become 2
        counter.increment();
        System.out.println(counter.getMinimumCount()); // Should print 2

        // Invoke increment four more times
        // Prediction: The value will roll over to 1 after reaching 5
        counter.increment();
        counter.increment();
        counter.increment();
        counter.increment();
        System.out.println(counter.getMinimumCount()); // Should print 1

        // Part 2
        LimitedCounter stop = new LimitedCounter(1,5);
        // Predict the initial value
        // Prediction: The initial value will be 1
        System.out.println(stop.getMinimumCount()); // Should print 1

        // Invoke increment
        // Prediction: The value will increase by 1 to become 2
        stop.StopCounting();
        System.out.println(stop.getMinimumCount()); // Should print 2

        // Invoke increment four more times
        // Prediction: The value will roll over to 5 after reaching 5
        stop.StopCounting();
        stop.StopCounting();
        stop.StopCounting();
        stop.StopCounting();
        System.out.println(stop.getMinimumCount()); // Should print 5


        // Part 4 invoking is already created in the first part, no need for extra object.
    }

    }



