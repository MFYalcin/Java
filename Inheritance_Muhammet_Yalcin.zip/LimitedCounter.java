public class LimitedCounter extends Counter {

    public void countUp() {
        if (!isAtMaximum()) {
            super.increment();
        }
    }

    public LimitedCounter(int minimumCount, int maximumCount) {
        super(minimumCount,maximumCount); // This calls the Counter(int startValue) constructor
    }

}



