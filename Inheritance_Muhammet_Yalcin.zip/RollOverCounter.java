public class RollOverCounter extends Counter {

    public void countUp() {
        if (!isAtMaximum()) {
            super.incrementCount();
        } else {
            super.reset();
        }
    }

    public RollOverCounter(int minimumCount, int maximumCount) {
        super(minimumCount,maximumCount);// This calls the Counter(int startValue) constructor
    }
}