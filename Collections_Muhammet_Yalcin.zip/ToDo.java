import java.util.LinkedList;

public class ToDo {
    private static int count = 1;
    private int itemNumber;
    private int hours;
    private int minutes;
    private boolean completed;
    private String title;


    public int getMinutes(){
        return minutes;
    }

    public int getHours(){
        return hours;
    }





    public ToDo(String title, boolean completed) {
        // Increment count by 1 for each new ToDo object


        // Set class attributes based on constructor parameters
        this.title = title;
        this.completed = completed;
        this.itemNumber = count++;


    }

    // Getters and setters for the attributes can be added here
    // For simplicity, I'll only show the getters here

    public String getTitle() {
        return title;
    }

    public boolean isCompleted() {
        return completed;
    }

    public int getItemNumber() {
        return itemNumber;
    }

    public ToDo() {
        this.title = "No Item";
        this.completed = false;
        this.itemNumber = 0;

    }
    public void printItem() {
        if (!completed){
            System.out.println("Item " + itemNumber +":"+title+"|"+"Not Completed");
        }
        else{
            System.out.println("Item " + itemNumber +":"+title+"|"+"Completed at "+hours+":"+minutes);
        }

    }
    public void convertTime(String timeString) {
        if (timeString.length() != 5) {
            hours = -1;
            minutes = -1;
            return;
        }

        try {
            int hoursValue = Integer.parseInt(timeString.substring(0, 2));
            int minutesValue = Integer.parseInt(timeString.substring(3, 5));

            if (hoursValue > 23 || minutesValue > 59) {
                hours = -1;
                minutes = -1;

            } else {
                hours = hoursValue;
                minutes = minutesValue;

            }
        } catch (NumberFormatException e) {
            hours = -1;
            minutes = -1;

        }



    }
}