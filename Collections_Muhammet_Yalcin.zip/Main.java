import java.util.LinkedList;
public class Main {
    public static void main(String[] args) {
        /*ToDo todo01 = new ToDo("Walk Cat", false);
        ToDo todo02 = new ToDo("Walk Kids", false);

        System.out.println(todo01.getTitle());
        System.out.println(todo01.isCompleted());
        System.out.println(todo01.getItemNumber());
        System.out.println(todo02.getTitle());
        System.out.println(todo02.isCompleted());
        System.out.println(todo02.getItemNumber());

        todo01.printItem();
        todo02.printItem();

        ToDo todoC = new ToDo();
        todoC.convertTime("14:30"); */

        LinkedList<ToDo> todoList = new LinkedList<>();
        for (ToDo todo : todoList) {
            System.out.println("Item Number: " + todo.getItemNumber());
            System.out.println("Item Title: " + todo.getTitle());
            System.out.println("Completed: " + (todo.isCompleted() ? "Yes" : "No"));

            if (todo.isCompleted()) {
                System.out.println("Time: " + todo.getHours() + ":" + todo.getMinutes());
            } else {
                System.out.println("Time: Invalid time format");
            }


        }
            System.out.println();

        // Add 4 nodes to the linked list with time for each task
        ToDo todo1 = new ToDo("Walk Dog", false);
        todo1.convertTime("14:30");
        todoList.add(todo1);

        ToDo todo2 = new ToDo("Walk Cat", true);
        todo2.convertTime("16:45");
        todoList.add(todo2);

        ToDo todo3 = new ToDo("Walk Hamster", false);
        todo3.convertTime("17:30");
        todoList.add(todo3);

        ToDo todo4 = new ToDo("Walk Kids", false);
        todo4.convertTime("19:15");
        todoList.add(todo4);

    todo1.printItem();
    todo2.printItem();
    todo3.printItem();
    todo4.printItem();
    }


}