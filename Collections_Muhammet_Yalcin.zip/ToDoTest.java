import org.junit.Test;
import static org.junit.Assert.*;

public class ToDoTest {

    @Test
    public void testDefaultConstructor() {
        ToDo todo = new ToDo();
        assertEquals("No Item", todo.getTitle());
        assertFalse(todo.isCompleted());
        assertEquals(0, todo.getItemNumber());


    }

    @Test
    public void testOverloadedConstructor() {
        ToDo todo = new ToDo("Walk Dog", false);
        assertEquals("Walk Dog", todo.getTitle());
        assertFalse(todo.isCompleted());
        assertTrue(todo.getItemNumber() > 0);

    }

    @Test
    public void testConvertTime() {
        ToDo todo1 = new ToDo();
        ToDo todo2 = new ToDo();

        todo1.convertTime("12:40");
        todo2.convertTime("25:70");

        assertTrue(todo1.isCompleted());
        assertEquals(12, todo1.getHours());
        assertEquals(40, todo1.getMinutes());

        assertFalse(todo2.isCompleted());
        assertEquals(-1, todo2.getHours());
        assertEquals(-1, todo2.getMinutes());
    }
}
