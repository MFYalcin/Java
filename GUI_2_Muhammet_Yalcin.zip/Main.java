import javax.swing.*;
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
              //  FirstGui gui = new FirstGui();
               // gui.show();
                FirstGui gui2 = new FirstGui("App Window", 600, 250);
                gui2.show();


            }

        });

    }


}