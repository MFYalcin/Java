import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FirstGui {
    private JFrame window;


    public FirstGui() {
        window = new JFrame();
        window.setTitle("Lab 11");
        window.setSize(600, 400);
        window.setLocationRelativeTo(null);  // This centers the window on the screen
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public FirstGui(String title, int width, int height) {
        window = new JFrame();
        window.setTitle(title);
        window.setSize(width, height);
        window.setLocationRelativeTo(null);
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
        panel.setBackground(Color.PINK);
        panel.setPreferredSize(new Dimension(150, 50));

        Button button1 = new Button("Process");
        Button button2 = new Button("Clear");
        Button button3 = new Button("Quit");

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);


        window.add(panel, BorderLayout.EAST);

        JPanel textPanel = new JPanel();
        // Create a TextField for "First Name" and add to the JPanel
        JTextField firstNameField = createTextField("First Name");
        textPanel.add(firstNameField);

        // Create a TextField for "Last Name" and add to the JPanel
        JTextField lastNameField = createTextField("Last Name");
        textPanel.add(lastNameField);
        window.add(textPanel, BorderLayout.CENTER);
        //window.add(panel, BorderLayout.EAST);
        textPanel.setPreferredSize(new Dimension(150, 50));


        JPanel label = new JPanel();
        // Create a TextField for "First Name" and add to the JPanel
        JLabel firstNameField2 = createLabel("First Name");
        label.add(firstNameField2);

        // Create a TextField for "Last Name" and add to the JPanel
        JLabel lastNameField2 = createLabel("Last Name");
        label.add(lastNameField2);
        window.add(label, BorderLayout.WEST);
        //window.add(panel, BorderLayout.EAST);
        label.setPreferredSize(new Dimension(150, 50));


        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // the action that we want to perform
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                System.out.println("Hello "+ firstName+ " "+ lastName);
            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // the action that we want to perform
                firstNameField.setText("");
                lastNameField.setText("");
            }
        });

        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // the action that we want to perform
                System.exit(0);
            }
        });

    }


    public void show() {
        window.setVisible(true);
    }

    public JTextField createTextField(String tip) {
        JTextField field = new JTextField(10); // Create a TextField with width of 10 columns
        field.setToolTipText(tip); // Set tool tip text to the input parameter
        return field;
    }

    // Method to create a JLabel
    public JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        Font font = new Font("Calibri", Font.PLAIN, 18);
        label.setFont(font);
        label.setBorder(BorderFactory.createLineBorder(Color.black));
        return label;
    }
}

