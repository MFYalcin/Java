import javax.swing.*;
import java.awt.*;

public class FirstGui {
    private JFrame window;
    public FirstGui() {
        window = new JFrame();
        window.setTitle("Lab 11");
        window.setSize(600, 400);
        window.setLocationRelativeTo(null);  // This centers the window on the screen
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public FirstGui(String title, int width, int height) {
        window = new JFrame();
        window.setTitle(title);
        window.setSize(width, height);
        window.setLocationRelativeTo(null);
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panel.setBackground(Color.PINK);

        Button button1 = new Button("1st button");
        Button button2 = new Button("2nd button");
        Button button3 = new Button("3rd button");

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);

        JPanel frame = new JPanel();
        frame.add(panel, BorderLayout.WEST);
        window.add(panel, BorderLayout.CENTER);
        panel.setPreferredSize(new Dimension(150, 50));
    }

    public void show() {
        window.setVisible(true);
    }
}
